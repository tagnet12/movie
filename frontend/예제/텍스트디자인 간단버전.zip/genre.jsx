import {Link, Routes, Route} from "react-router-dom";
import { Dropdown } from 'react-bootstrap';
import Detail from './detail.jsx';
import { info } from './info.js'
import { useState } from "react";
import './genre.css';

function Genre({setImgNo}){

  let [sectionTitle, setSectionTitle] = new useState('전체');
  let [selectedItem, setSelectedItem] = new useState('장르별 선택');
  let [selectGenre,setSelectGenre] = new useState('전체');

  const genreChange = (genre)=>{
    setSectionTitle(genre);
    setSelectedItem(genre);
    setSelectGenre(genre);
  }

  const infoFilter = info.filter(movie => movie.genre === selectGenre);

    return(
        <div>
            {/* 헤더 */}
            <div className="genre-header">
              <h1>🎬 장르별 영화</h1>
            </div>

            {/* 드롭다운 */}
            <div className="dropdown-section">
              <Dropdown>
                <Dropdown.Toggle variant="primary" id="dropdown-genre">
                  {selectedItem}
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item onClick={()=> genreChange('전체')}>전체</Dropdown.Item>
                  <Dropdown.Item onClick={()=> genreChange('스릴러')}>스릴러</Dropdown.Item>
                  <Dropdown.Item onClick={()=> genreChange('공포')}>공포</Dropdown.Item>
                  <Dropdown.Item onClick={()=> genreChange('액션')}>액션</Dropdown.Item>
                  <Dropdown.Item onClick={()=> genreChange('판타지')}>판타지</Dropdown.Item>
                  <Dropdown.Item onClick={()=> genreChange('애니메이션')}>애니메이션</Dropdown.Item>
                  <Dropdown.Item onClick={()=> genreChange('코믹')}>코믹</Dropdown.Item>
                  <Dropdown.Item onClick={()=> genreChange('로맨스')}>로맨스</Dropdown.Item>
                  <Dropdown.Item onClick={()=> genreChange('드라마')}>드라마</Dropdown.Item>
                  <Dropdown.Item onClick={()=> genreChange('SF')}>SF</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>

            <Routes>
            <Route path='/detail/:id' element={<Detail setImgNo={setImgNo} />}/>    

            <Route path='/' element={      
              <>   
                <div className='container'>
                  <div className='row'>
                    <h2 className="section-title">{sectionTitle} 목록</h2>
                    { 
                      selectGenre === '전체'
                      ? <ImageList allFlag={'all'} selectGenre={''} key="all" />
                      : infoFilter.length === 0 
                        ? <NoList key='no-list' />
                        : <ImageList allFlag={'notAll'} selectGenre={selectGenre} key="selectGenre" />
                    }
                  </div>
                </div>
              </>
            }/>     
          </Routes>            
        </div>
    )
}

function ImageList({allFlag, selectGenre}){
  return(
    info.map( (movie, i) => { 
      if( allFlag === 'all' )
      {
        return( <ImageListView movie={movie} i={i} /> )
      }else{
        if( movie.genre === selectGenre ){
          return( <ImageListView movie={movie} i={i} /> )
        }
      }
    })
  )
}

function ImageListView({movie, i}){
  return(
    <div className='col-md-4' key={i}> 
      <Link to={`/detail/${i}`}>
        <img className='imgList' src={movie.image} alt={movie.title} width='80%' height='60%' /> 
      </Link>
      <div>{movie.title}({movie.date})</div>
    </div>
  )
}

function NoList(){
  return(
    <div className="no-list">
      <p>조회된 내용이 없습니다.</p>
    </div>
  )
}

export default Genre;
